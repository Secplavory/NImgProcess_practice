#include "pch.h"
#include "MyDLL.h"

MYDLL_API int __cdecl Add(int a, int b)
{
	return a + b;
}