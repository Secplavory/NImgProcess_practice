#define MYDLL_API __declspec(dllexport)

#ifdef __cplusplus
extern "C" {
#endif

	MYDLL_API int __cdecl Add(int a, int b);

#ifdef __cplusplus
}
#endif // __cplusplus
